# What pysed covers

This is the part of GNU sed 4.9 that `python3 /app/pysed/sed.py` has to reproduce, with `LC_ALL=C`; the manual is `/app/docs/sed.txt`.

## Covered

- the options `-n`, `-E` and `-s`, each given as its own argument before the script, and scripts given with `-e SCRIPT` (repeatable, the pieces joined by newlines) or as the first non-option argument, followed by the names of input files, or none to read standard input;
- from chapter 3 of the manual: `a`, `i` and `c` in their one-line and multi-line forms, `b`, `t`, `T` and `:label`, `{` `}` blocks, `!`, comments and a script whose first two characters are `#n`, `d`, `D`, `g`, `G`, `h`, `H`, `x`, `n`, `N`, `p`, `P`, `q` and `Q` with their exit codes, `=`, `z`, and `s` with the flags `g`, `p` and a number, in any combination. The commands `e`, `F`, `l`, `r`, `R`, `v`, `w`, `W` and `y` and the `s` flags `e`, `i`, `I`, `m`, `M` and `w` are not used;
- every address form in chapter 4, including `first~step`, `addr1,+N`, `addr1,~N` and `0,/regexp/`, with any delimiter for a regular expression; the `I` and `M` modifiers are not used;
- the regular expressions of chapter 5, basic and extended: the operators of sections 5.3 and 5.4, groups (whose text `\1` to `\9` and `&` put into a replacement), bracket expressions with ranges, negation and the `[:class:]` names, the escapes `\w`, `\W`, `\s`, `\S`, `\b`, `\B`, `\<` and `\>` outside bracket expressions, and the escapes `\a`, `\f`, `\n`, `\r`, `\t` and `\v` of section 5.8 wherever they may appear, bracket expressions included; inside a bracket expression any other backslash is an ordinary character, as section 5.5 says. Back-references inside a regular expression (`\1` in the pattern itself), `` \` ``, `\'`, `\cX`, `\dNNN`, `\oNNN`, `\xHH`, equivalence classes, collating symbols and the case-conversion escapes `\L`, `\U`, `\l`, `\u` and `\E` are not used. Matching is POSIX leftmost-longest: of the matches that start at the leftmost possible position, the longest one wins, whichever alternative of a `|` produces it, whatever the manual's section on `\|` suggests. When several ways of matching give that same text, which parts the groups capture is left open.

## Points the manual leaves open

Nothing sets `POSIXLY_CORRECT`, so `N` with no next line to read ends the cycle there, printing the pattern space unless `-n` is given, as the manual's entry for `N` says of GNU sed. A few more points the manual leaves open are settled the way GNU sed 4.9 does: under `-s` every file also starts with an empty hold space; `Q` drops text queued by `a` along with the pattern space; once a named file that cannot be read has been reached, the exit status is 2 even if `q` or `Q` then gives a code; and `//` repeats the regular expression last used while the script runs, so no script reaches it before another one has been tried.

## Where GNU sed 4.9 departs from its manual

In these places the binary does not do what the manual says, and the behaviour is left open: a second `*` right after a repetition in a basic regular expression, `^` or `$` in an extended one anywhere but at the start or end of the whole expression, of a group or of an alternative, a range whose first address is a line number that `n` or `N` already read past, the next line after an `addr1,+N` or `addr1,~N` range whose end `n` or `N` read past, a `T` that does not branch (GNU sed clears the substitution flag there as well), a backslash right after the whitespace of a one-line `a`, `i` or `c`, and a `c` whose range is still open when the input ends.
