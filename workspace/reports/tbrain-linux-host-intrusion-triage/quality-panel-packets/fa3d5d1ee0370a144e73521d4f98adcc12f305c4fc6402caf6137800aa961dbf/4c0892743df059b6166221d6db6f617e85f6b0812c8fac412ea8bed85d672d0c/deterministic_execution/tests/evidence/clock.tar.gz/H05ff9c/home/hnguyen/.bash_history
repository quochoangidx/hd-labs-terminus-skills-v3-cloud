echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPm46hZqaoZ6SgR5qS+Cg/X+TJKzwPjSAW0q2N29QBF/ hnguyen@laptop' >> ~/.ssh/authorized_keys
journalctl -u nginx | tail
uptime
top -bn1 | head
journalctl -u nginx | tail
df -h
top -bn1 | head
top -bn1 | head
