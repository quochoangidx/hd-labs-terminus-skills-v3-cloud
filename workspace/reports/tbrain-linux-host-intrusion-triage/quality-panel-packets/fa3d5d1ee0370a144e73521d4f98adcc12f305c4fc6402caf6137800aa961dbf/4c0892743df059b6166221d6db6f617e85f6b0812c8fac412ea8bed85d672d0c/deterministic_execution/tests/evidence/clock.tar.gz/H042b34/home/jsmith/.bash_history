echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFE/ds7WX+AIRDtrEjSfPe0ZnoNNZigSjV1E2kbEcCfC jsmith@laptop' >> ~/.ssh/authorized_keys
df -h
uptime
journalctl -u nginx | tail
journalctl -u nginx | tail
journalctl -u nginx | tail
uptime
df -h
journalctl -u nginx | tail
uptime
