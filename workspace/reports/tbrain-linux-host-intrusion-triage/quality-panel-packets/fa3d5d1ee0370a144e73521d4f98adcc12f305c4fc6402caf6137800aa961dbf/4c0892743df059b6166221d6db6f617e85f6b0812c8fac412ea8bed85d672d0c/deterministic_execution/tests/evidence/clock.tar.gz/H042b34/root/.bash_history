systemctl status cron
apt-get update
id
vi /etc/cron.d/netcheck
vi /etc/rc.local
touch -r /etc/hostname /etc/rc.local
exit
