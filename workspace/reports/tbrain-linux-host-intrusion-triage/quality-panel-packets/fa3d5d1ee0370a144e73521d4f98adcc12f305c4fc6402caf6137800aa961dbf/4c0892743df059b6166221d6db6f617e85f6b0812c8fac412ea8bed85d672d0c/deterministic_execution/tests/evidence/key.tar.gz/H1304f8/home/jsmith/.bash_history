#1722104541
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIL1mN5/1D3eJqhtzmudsoCE2IJRq/Q0ZaBKAzWMpv7ad jsmith@laptop' >> ~/.ssh/authorized_keys
#1722620539
df -h
#1722656589
df -h
#1722702279
top -bn1 | head
#1722929993
journalctl -u nginx | tail
#1723166393
top -bn1 | head
#1723330983
journalctl -u nginx | tail
