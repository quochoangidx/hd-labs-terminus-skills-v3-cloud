chmod 644 /etc/cron.d/logs-rotate
systemctl status cron
exit
vi /etc/ssh/sshd_config
ls /etc/cron.d
