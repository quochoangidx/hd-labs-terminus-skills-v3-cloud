echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFZBiQfcS5d+VRgU5Rna5FCMpi6EYk9TTy7cOv5y2Ekx alice@laptop' >> ~/.ssh/authorized_keys
journalctl -u nginx | tail
top -bn1 | head
df -h
df -h
top -bn1 | head
uptime
journalctl -u nginx | tail
