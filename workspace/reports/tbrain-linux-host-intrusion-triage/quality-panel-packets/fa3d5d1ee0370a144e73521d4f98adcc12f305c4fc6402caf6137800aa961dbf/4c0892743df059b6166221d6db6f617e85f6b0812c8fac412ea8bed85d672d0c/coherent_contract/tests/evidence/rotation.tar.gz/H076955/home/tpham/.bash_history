#1681322046
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILnxpnFGpFGvWfbqv7Kx0nfGxmNsF9BsQV8G6Q3ooran tpham@laptop' >> ~/.ssh/authorized_keys
#1681845290
df -h
#1681916241
journalctl -u nginx | tail
#1681917459
df -h
#1681922838
uptime
#1681939463
journalctl -u nginx | tail
#1681991228
df -h
