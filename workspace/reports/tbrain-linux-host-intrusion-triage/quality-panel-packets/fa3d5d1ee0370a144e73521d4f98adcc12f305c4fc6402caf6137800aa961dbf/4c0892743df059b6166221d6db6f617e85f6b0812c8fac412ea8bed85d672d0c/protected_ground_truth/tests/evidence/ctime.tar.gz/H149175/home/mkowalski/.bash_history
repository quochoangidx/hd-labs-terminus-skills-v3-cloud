#1612854328
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIEirl82rTDG51mPdBRRMSAoT3GN7CuEQ0guQxozlLubO mkowalski@laptop' >> ~/.ssh/authorized_keys
#1613203779
top -bn1 | head
#1613221965
top -bn1 | head
#1613235600
uptime
#1613299881
df -h
#1613474996
uptime
#1613518020
df -h
#1613800224
uptime
#1613859498
journalctl -u nginx | tail
#1614043334
df -h
