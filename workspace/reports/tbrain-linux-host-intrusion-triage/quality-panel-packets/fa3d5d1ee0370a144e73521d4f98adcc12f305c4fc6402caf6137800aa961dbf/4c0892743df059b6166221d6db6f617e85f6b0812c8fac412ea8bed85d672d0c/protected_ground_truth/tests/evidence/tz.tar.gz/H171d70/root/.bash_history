exit
exit
id
vi /etc/cron.d/apt-cache-clean
touch -r /etc/hostname /etc/cron.d/apt-cache-clean
exit
