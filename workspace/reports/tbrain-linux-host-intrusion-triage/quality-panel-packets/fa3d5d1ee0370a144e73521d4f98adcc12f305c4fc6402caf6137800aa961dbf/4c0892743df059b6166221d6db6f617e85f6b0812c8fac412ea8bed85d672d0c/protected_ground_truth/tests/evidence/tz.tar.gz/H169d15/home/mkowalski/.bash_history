echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJW7x95Uc/HWzE27QEZ7acIaPx4bF0eT1ffeC5oZQyx3 mkowalski@laptop' >> ~/.ssh/authorized_keys
df -h
top -bn1 | head
top -bn1 | head
journalctl -u nginx | tail
df -h
df -h
df -h
