vi /etc/ssh/sshd_config
ls /etc/cron.d
vi /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
apt-get update
