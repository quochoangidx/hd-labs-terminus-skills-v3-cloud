#1585931752
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOGAnsm3s3YRef5tvljt08/630yVw7087MWbK2Mt+uIP tpham@laptop' >> ~/.ssh/authorized_keys
#1586627363
top -bn1 | head
#1586643623
uptime
#1586668923
journalctl -u nginx | tail
#1586790148
df -h
#1586944637
top -bn1 | head
#1587142014
uptime
#1587161476
df -h
