#1950074042
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIc0SwwNIBJdJ5OpYIT4Z0SlSdcmqpw0UIqHxNU+yrzS mkowalski@laptop' >> ~/.ssh/authorized_keys
#1951701409
uptime
#1951707014
journalctl -u nginx | tail
#1951933423
journalctl -u nginx | tail
#1951948708
top -bn1 | head
#1951992928
top -bn1 | head
#1952085521
journalctl -u nginx | tail
#1952133985
uptime
#1952228388
top -bn1 | head
#1952296143
journalctl -u nginx | tail
#1952321129
uptime
