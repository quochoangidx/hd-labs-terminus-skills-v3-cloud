echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOB69a0HhL6RD6kYXaUZG/6qFha5yALdBEnqe0irQRlW mkowalski@laptop' >> ~/.ssh/authorized_keys
journalctl -u nginx | tail
top -bn1 | head
top -bn1 | head
uptime
top -bn1 | head
journalctl -u nginx | tail
top -bn1 | head
uptime
top -bn1 | head
uptime
