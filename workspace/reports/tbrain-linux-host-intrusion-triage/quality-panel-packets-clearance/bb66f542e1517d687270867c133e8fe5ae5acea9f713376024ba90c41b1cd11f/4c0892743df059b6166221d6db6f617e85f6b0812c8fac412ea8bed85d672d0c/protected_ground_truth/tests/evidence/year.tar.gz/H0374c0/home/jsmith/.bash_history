echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIAXbfUGCTvalQa0epKkAnEhBWtWj4xcSdpYgLg8TPiFu jsmith@laptop' >> ~/.ssh/authorized_keys
uptime
df -h
top -bn1 | head
uptime
uptime
df -h
uptime
uptime
df -h
journalctl -u nginx | tail
