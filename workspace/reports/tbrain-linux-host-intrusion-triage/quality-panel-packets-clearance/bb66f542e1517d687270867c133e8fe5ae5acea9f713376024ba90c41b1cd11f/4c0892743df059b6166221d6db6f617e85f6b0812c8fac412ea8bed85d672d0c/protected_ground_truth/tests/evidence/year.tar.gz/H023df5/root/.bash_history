#1608429418
chmod 644 /etc/cron.d/logs-rotate
#1608566078
apt-get update
#1608566152
ls /etc/cron.d
#1608566178
vi /etc/ssh/sshd_config
#1608566274
vi /etc/ssh/sshd_config
#1608566330
systemctl status cron
