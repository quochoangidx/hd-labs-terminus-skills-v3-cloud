#1703364812
systemctl status cron
#1703364920
systemctl status cron
#1703364992
exit
#1703365187
systemctl status cron
#1703820864
id
#1703821065
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDipgbq7Teg0DEWZn2yHw3yPGr7Dnkd94vl1Sh/9km9T root@vps' >> /root/.ssh/authorized_keys
#1703821078
exit
