#1702273855
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAICF/QYjZjuYE5QzFFGwKxiMDkEt3UqRGMIWepGZ3fBRA alice@laptop' >> ~/.ssh/authorized_keys
#1703364772
df -h
#1703365978
uptime
#1703487363
top -bn1 | head
#1703926917
df -h
#1703947520
df -h
#1703970084
df -h
#1703980966
top -bn1 | head
#1703991895
journalctl -u nginx | tail
#1704038792
top -bn1 | head
#1704097195
uptime
