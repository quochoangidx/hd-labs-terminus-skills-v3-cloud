#1866139829
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGdWGMAOuMJxpYOiqpfi6oQ2ilEBO7hDRbvFJcz5WfF5 tpham@laptop' >> ~/.ssh/authorized_keys
#1867672723
uptime
#1867823087
uptime
#1867831367
uptime
#1867943737
df -h
#1868007464
df -h
#1868017636
df -h
#1868116374
journalctl -u nginx | tail
#1868199959
uptime
#1868259543
df -h
#1868344005
df -h
#1868411092
top -bn1 | head
