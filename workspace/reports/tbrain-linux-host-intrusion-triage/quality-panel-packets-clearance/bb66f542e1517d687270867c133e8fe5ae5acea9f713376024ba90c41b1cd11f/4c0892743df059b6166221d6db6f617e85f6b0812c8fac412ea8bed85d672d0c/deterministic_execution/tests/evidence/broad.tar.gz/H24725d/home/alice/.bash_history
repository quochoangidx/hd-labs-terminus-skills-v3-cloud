echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFAfb6IHSmSx/96DzpTK2+0BMFgk1v9/h4ahJ2HVPqE0 alice@laptop' >> ~/.ssh/authorized_keys
journalctl -u nginx | tail
df -h
top -bn1 | head
