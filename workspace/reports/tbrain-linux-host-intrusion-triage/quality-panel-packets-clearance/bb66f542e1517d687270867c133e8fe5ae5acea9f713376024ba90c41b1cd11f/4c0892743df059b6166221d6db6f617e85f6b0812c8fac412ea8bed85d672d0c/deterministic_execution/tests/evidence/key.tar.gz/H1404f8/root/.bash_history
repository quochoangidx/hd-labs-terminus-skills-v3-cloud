apt-get update
vi /etc/ssh/sshd_config
id
exit
