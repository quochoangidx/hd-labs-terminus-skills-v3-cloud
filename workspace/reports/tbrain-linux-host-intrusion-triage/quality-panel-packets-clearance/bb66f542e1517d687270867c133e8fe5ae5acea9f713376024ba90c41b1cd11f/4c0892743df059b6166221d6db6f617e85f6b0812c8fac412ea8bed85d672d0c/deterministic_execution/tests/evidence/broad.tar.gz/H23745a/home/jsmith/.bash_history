echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAILbLlSJ9bLMo7Zy5zg4CkUlilJU19ndjg7oUAzZ3t23z jsmith@laptop' >> ~/.ssh/authorized_keys
df -h
top -bn1 | head
top -bn1 | head
top -bn1 | head
journalctl -u nginx | tail
top -bn1 | head
journalctl -u nginx | tail
df -h
journalctl -u nginx | tail
uptime
journalctl -u nginx | tail
