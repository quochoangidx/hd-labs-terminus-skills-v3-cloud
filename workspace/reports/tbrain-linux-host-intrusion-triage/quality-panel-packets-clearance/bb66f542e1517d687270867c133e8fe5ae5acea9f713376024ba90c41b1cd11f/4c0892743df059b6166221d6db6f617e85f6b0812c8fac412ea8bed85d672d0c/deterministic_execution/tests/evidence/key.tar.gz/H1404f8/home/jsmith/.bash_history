#1722111071
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIL1mN5/1D3eJqhtzmudsoCE2IJRq/Q0ZaBKAzWMpv7ad jsmith@laptop' >> ~/.ssh/authorized_keys
#1722627069
df -h
#1722663119
df -h
#1722708809
top -bn1 | head
#1722936523
journalctl -u nginx | tail
#1723172923
top -bn1 | head
#1723337513
journalctl -u nginx | tail
