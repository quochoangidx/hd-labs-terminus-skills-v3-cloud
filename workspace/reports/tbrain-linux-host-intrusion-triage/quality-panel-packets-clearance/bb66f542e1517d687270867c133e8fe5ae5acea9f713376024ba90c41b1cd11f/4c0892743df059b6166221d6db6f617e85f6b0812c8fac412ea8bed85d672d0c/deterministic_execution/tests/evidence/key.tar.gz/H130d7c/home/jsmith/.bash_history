echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIHdtaoEfeGgxVWKDnDgc/P2esNzKi5MrMGDPdYxt7HCk jsmith@laptop' >> ~/.ssh/authorized_keys
journalctl -u nginx | tail
top -bn1 | head
journalctl -u nginx | tail
uptime
uptime
top -bn1 | head
top -bn1 | head
