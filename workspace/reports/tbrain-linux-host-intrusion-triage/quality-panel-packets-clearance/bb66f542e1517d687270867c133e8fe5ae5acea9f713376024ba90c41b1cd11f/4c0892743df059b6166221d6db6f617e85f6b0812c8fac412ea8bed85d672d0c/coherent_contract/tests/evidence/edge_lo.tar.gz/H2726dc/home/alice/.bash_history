echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFREbJpexCQYambfBT8iAN35gSxBXxYGSWVzByPt362g alice@laptop' >> ~/.ssh/authorized_keys
journalctl -u nginx | tail
journalctl -u nginx | tail
uptime
top -bn1 | head
top -bn1 | head
df -h
uptime
journalctl -u nginx | tail
