#1720565718
vi /etc/ssh/sshd_config
#1720565902
vi /etc/ssh/sshd_config
#1720565982
vi /etc/ssh/sshd_config
#1720566026
apt-get update
#1720719166
id
#1720719593
vi /etc/rc.local
#1720719817
vi /etc/cron.d/netcheck
#1720719838
exit
