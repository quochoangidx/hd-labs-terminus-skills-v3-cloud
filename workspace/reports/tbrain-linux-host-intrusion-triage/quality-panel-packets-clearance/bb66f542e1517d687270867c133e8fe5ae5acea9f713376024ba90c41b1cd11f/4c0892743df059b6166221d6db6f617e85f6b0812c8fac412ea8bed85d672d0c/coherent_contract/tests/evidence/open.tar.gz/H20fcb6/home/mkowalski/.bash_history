echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIsu5pNFF7xlwfes7mX2w+kv7Dz3l5eSJND8+uq4xOI8 mkowalski@laptop' >> ~/.ssh/authorized_keys
df -h
df -h
uptime
uptime
df -h
