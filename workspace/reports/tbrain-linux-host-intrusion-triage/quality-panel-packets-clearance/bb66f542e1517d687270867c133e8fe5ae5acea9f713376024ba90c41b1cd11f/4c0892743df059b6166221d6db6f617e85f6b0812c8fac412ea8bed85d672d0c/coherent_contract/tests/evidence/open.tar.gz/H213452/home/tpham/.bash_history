echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFj9RNXLJ6EXJ1o3QOkyrkTMGph73zSI5QtNKK1J1/7+ tpham@laptop' >> ~/.ssh/authorized_keys
journalctl -u nginx | tail
df -h
df -h
