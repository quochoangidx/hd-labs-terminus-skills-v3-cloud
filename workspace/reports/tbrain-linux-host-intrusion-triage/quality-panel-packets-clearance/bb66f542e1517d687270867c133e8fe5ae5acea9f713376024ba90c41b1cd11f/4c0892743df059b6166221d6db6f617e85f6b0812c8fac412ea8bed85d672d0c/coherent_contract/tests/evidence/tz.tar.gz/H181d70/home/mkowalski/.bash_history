#1950074619
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIc0SwwNIBJdJ5OpYIT4Z0SlSdcmqpw0UIqHxNU+yrzS mkowalski@laptop' >> ~/.ssh/authorized_keys
#1951701986
uptime
#1951707591
journalctl -u nginx | tail
#1951934000
journalctl -u nginx | tail
#1951949285
top -bn1 | head
#1951993505
top -bn1 | head
#1952086098
journalctl -u nginx | tail
#1952134562
uptime
#1952228388
top -bn1 | head
#1952296143
journalctl -u nginx | tail
#1952321129
uptime
