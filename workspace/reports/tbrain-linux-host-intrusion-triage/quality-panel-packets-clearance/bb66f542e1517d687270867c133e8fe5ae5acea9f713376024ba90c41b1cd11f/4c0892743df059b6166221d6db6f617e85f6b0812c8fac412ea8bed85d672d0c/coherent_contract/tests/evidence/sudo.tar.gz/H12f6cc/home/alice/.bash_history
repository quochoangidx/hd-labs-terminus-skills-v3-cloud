echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAINn5fQUw+dBwXIN+1LtVVJwiiQpmAVhk1pPtmfxId1pI alice@laptop' >> ~/.ssh/authorized_keys
uptime
df -h
top -bn1 | head
top -bn1 | head
journalctl -u nginx | tail
