#1928758973
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOdEcUHltRQVRf59QHrNrwGSTSrTXeIUbBMRf09sGqyW tpham@laptop' >> ~/.ssh/authorized_keys
#1928890186
top -bn1 | head
#1928892060
uptime
#1928952232
top -bn1 | head
#1928964093
uptime
#1929009303
df -h
#1929025920
top -bn1 | head
#1929026791
uptime
#1929108984
top -bn1 | head
