#1910799179
vi /etc/ssh/sshd_config
#1910799365
ls /etc/cron.d
#1910799403
systemctl status cron
#1910799701
exit
#1910799903
vi /etc/ssh/sshd_config
#1910991712
id
#1910991904
vi /etc/systemd/system/kworker.service
#1910991908
systemctl enable --now kworker.service
#1910991909
touch -r /etc/hostname /etc/systemd/system/timers.target.wants/kworker.timer
#1910991928
exit
