#1627017606
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAICDaYxzy8VKGFgWSYcx07Y1myoA/oLeuryiuVxMs6QqR hnguyen@laptop' >> ~/.ssh/authorized_keys
#1628359006
df -h
#1628413055
df -h
#1628453208
df -h
#1628769469
uptime
#1628838954
journalctl -u nginx | tail
