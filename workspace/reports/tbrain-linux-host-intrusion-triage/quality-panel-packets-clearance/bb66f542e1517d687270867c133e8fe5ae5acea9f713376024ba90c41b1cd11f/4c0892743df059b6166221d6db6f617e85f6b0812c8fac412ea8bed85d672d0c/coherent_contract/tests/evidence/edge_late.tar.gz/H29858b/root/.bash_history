chmod 644 /etc/cron.d/logs-rotate
systemctl status cron
systemctl status cron
ls /etc/cron.d
apt-get update
