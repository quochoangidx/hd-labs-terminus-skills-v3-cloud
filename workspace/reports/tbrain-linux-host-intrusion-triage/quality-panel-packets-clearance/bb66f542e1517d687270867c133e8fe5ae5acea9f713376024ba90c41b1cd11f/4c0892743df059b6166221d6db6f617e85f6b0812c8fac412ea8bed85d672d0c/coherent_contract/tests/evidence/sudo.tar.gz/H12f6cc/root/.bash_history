#1734833906
ls /etc/cron.d
#1734833971
vi /etc/ssh/sshd_config
#1734834254
vi /etc/ssh/sshd_config
#1734834485
apt-get update
