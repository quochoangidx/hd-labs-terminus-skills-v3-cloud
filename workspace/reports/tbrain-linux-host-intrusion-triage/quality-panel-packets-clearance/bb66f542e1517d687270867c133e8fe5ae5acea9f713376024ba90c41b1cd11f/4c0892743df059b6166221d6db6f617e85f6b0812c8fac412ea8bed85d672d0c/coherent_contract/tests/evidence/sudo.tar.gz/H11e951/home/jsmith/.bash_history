echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDh2oPc3Nak2xUo4dflDTjFfGa2egJ8BXdlyE1MM3ugt jsmith@laptop' >> ~/.ssh/authorized_keys
top -bn1 | head
top -bn1 | head
journalctl -u nginx | tail
uptime
df -h
uptime
uptime
