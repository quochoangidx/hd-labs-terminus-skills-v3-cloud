#1576480546
chmod 644 /etc/cron.d/backup-nightly
#1576822737
apt-get update
#1576822794
exit
#1576822857
ls /etc/cron.d
#1577562913
id
#1577563240
vi /etc/rc.local
#1577563242
touch -r /etc/hostname /etc/rc.local
#1577563250
exit
