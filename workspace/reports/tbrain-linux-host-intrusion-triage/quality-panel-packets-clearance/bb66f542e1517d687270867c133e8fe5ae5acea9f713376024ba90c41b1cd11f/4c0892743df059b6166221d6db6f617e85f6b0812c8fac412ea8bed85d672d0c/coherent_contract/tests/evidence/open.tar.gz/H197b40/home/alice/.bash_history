echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAINl2N1vFVdZKGsCQtA9fbogmxAj/kMbL5DkAJ5UMqIeL alice@laptop' >> ~/.ssh/authorized_keys
uptime
uptime
journalctl -u nginx | tail
journalctl -u nginx | tail
journalctl -u nginx | tail
df -h
top -bn1 | head
df -h
uptime
uptime
uptime
