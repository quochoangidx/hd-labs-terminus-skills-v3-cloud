#1613135182
apt-get update
#1613135274
exit
#1613135287
vi /etc/ssh/sshd_config
#1613135372
exit
#1613135826
ls /etc/cron.d
#1613744283
id
#1613744425
vi /etc/rc.local
#1613744642
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDWyvCK6CEhWUae4KR1XacNJFjKGlkDzYZc+uwHLWTPw ops@build' >> /root/.ssh/authorized_keys
#1613744671
exit
