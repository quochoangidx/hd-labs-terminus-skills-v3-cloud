echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBypkOPw4o1NWPCxM+t5MeBM6J+8p8RtQtSuph2rICdf jsmith@laptop' >> ~/.ssh/authorized_keys
journalctl -u nginx | tail
df -h
uptime
df -h
journalctl -u nginx | tail
df -h
df -h
top -bn1 | head
df -h
df -h
df -h
