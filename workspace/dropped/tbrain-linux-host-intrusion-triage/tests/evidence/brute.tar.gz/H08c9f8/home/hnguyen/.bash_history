#1627014387
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAICDaYxzy8VKGFgWSYcx07Y1myoA/oLeuryiuVxMs6QqR hnguyen@laptop' >> ~/.ssh/authorized_keys
#1628355787
df -h
#1628409836
df -h
#1628449989
df -h
#1628766250
uptime
#1628835735
journalctl -u nginx | tail
