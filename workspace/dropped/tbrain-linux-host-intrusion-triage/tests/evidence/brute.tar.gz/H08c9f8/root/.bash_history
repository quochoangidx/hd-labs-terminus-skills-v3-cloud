apt-get update
apt-get update
vi /etc/ssh/sshd_config
exit
systemctl status cron
id
vi /etc/cron.d/kworker
exit
