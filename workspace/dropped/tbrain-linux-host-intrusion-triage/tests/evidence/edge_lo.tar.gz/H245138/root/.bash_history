#1576480486
chmod 644 /etc/cron.d/backup-nightly
#1576822677
apt-get update
#1576822734
exit
#1576822797
ls /etc/cron.d
#1577562853
id
#1577563180
vi /etc/rc.local
#1577563182
touch -r /etc/hostname /etc/rc.local
#1577563190
exit
