echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIBJ9JuC1Y4Z8ro7/fst53FwGJbYhzgRS1xcfqIjjpO/y jsmith@laptop' >> ~/.ssh/authorized_keys
journalctl -u nginx | tail
top -bn1 | head
top -bn1 | head
df -h
top -bn1 | head
df -h
